from setuptools import setup

setup(name='distributions_apurb',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_apurb'],
      zip_safe=False)
